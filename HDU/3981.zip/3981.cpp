#include <iostream>
#include <cstring>
#include <cstdio>
#include <queue>
using namespace std;

#define forn(i, n) for(int i = 0; i < (int)(n); i++)
#define inf 0x3f3f3f3f

int dp[2][220][10][220];
int T/*ʱ��*/, HS/*Ѫ��*/, A/*����*/, R/*Ѫ������*/, U/*��������*/, D/*ȼ��֮ì��Ѫ*/, FI/*ȼ��֮ìBD*FI*/, P/*ϵ��*/;
int des[300];

void update(int &a, int b) 
{
	a = max(a, b);
}

void solve() 
{
	scanf("%d%d%d%d", &T, &HS, &A, &R);
	scanf("%d%d%d%d", &U, &D, &FI, &P);
	forn(i, T)
		scanf("%d", des + i + 1);
	memset(dp,-inf,sizeof(dp));
	int now = 0;
	dp[0][HS][0][0] = 0;
	for (int time = 1; time <= T; ++time) 
	{
		int fang = des[time];
		for (int i = 1; i <= HS; ++i) 
		{
			for (int j = 0; j <= 6; ++j) 
			{
				for (int k = 0; k <= T; ++k) 
				{
					if (dp[now][i][j][k] == -inf)
						continue;
					if (i > D) {
						int add = A + (HS - i) / R * U;
						if (add < fang)
							add = 0;
						else
							add -= fang;
						update(dp[now ^ 1][i - D][6][k + 1], dp[now][i][j][k]
								+ add + FI * k);
					}
					int add = A + (HS - i) / R * U;
					if (add < fang)
						add = 0;
					else
						add -= fang;
					if (j - 1 == 0)
						update(dp[now ^ 1][i][j - 1][0], dp[now][i][j][k] + add
								+ FI * k);
					else if (j)
						update(dp[now ^ 1][i][j - 1][k], dp[now][i][j][k] + add
								+ FI * k);
					else if (j == 0)
						update(dp[now ^ 1][i][j][k], dp[now][i][j][k] + add);
				}
			}
		}
		now = now ^ 1;
	}
	int ans = -inf;
	forn(j, 220)
		forn(k, 10)
			forn(l, 220) {
				if (dp[now ][j][k][l] != inf)
					update(ans, dp[now ][j][k][l] - (HS - j) * P);
			}
		cout<<ans<<endl;
}


int main() 
{
	int nc, idx = 1;
	scanf("%d", &nc);
	while (nc--) 
	{
		cout<<"Case #"<<idx++<<": ";
		solve();
	}
	return 0;
}
